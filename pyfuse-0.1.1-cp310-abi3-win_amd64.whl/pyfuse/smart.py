
import shutil
import os
import sys
from pathlib import Path

def copy_library(src_root: Path, dest_root: Path, lib_name: str):
    # Libraries can have metadata folders (dist-info), we need to move those too
    copied = False
    for item in src_root.glob(f"{lib_name}*"):
        dest_item = dest_root / item.name
        if item.is_dir():
            shutil.copytree(item, dest_item, dirs_exist_ok=True)
            copied = True
        else:
            shutil.copy2(item, dest_item)
            copied = True
    return copied

def toggle_library(lib_path: Path, disable: bool):
    if disable:
        target = lib_path.with_name(lib_path.name + ".disabled")
        if lib_path.exists():
            if target.exists(): shutil.rmtree(target)
            lib_path.rename(target)
            return "Disabled"
    else:
        disabled_path = lib_path.with_name(lib_path.name + ".disabled")
        if disabled_path.exists():
            if lib_path.exists(): shutil.rmtree(lib_path)
            disabled_path.rename(lib_path)
            return "Enabled"
    return "No change or already in state"

def inject_folder_to_sys_path(folder_path: Path):
    path_str = str(folder_path.absolute())
    if path_str not in sys.path:
        sys.path.insert(0, path_str)
        # Force environment variable so child processes use it too
        os.environ["PYTHONPATH"] = path_str + os.pathsep + os.environ.get("PYTHONPATH", "")
