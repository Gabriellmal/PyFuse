
import sys
import os
import typer
import subprocess
import shutil
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from . import smart

try:
    from . import pyfuse_core
    ENGINE = "RUST (TURBO)"
except ImportError:
    ENGINE = "PYTHON (STANDARD)"

app = typer.Typer(help=f"PyFuse: High-Speed Library Organizer [{ENGINE}]")
console = Console()

@app.command()
def create(name: str):
    """Create a new folder to act as a library container."""
    path = Path(name)
    path.mkdir(parents=True, exist_ok=True)
    console.print(f"[bold green]Folder created:[/bold green] {name}")

@app.command()
def install(package: str, folder: str = typer.Option(".", "--folder", "-f", help="Target folder for installation")):
    """Ultra-fast install into a specific folder."""
    target = Path(folder).absolute()
    target.mkdir(parents=True, exist_ok=True)
    console.print(f"[bold blue]Installing {package} into {folder}...[/bold blue]")
    cmd = [sys.executable, "-m", "pip", "install", package, "--target", str(target), "--no-user", "--upgrade"]
    subprocess.check_call(cmd)
    console.print(f"[bold green]Successfully installed {package} to {folder}[/bold green]")

@app.command()
def list_libs(folder: str = typer.Option(".", "--folder", "-f")):
    """Show all libraries in a folder using Rust parallel scan."""
    path = Path(folder).absolute()
    if not path.exists():
        console.print(f"[red]Folder {folder} does not exist.[/red]")
        return

    if ENGINE == "RUST (TURBO)":
        libs = pyfuse_core.fast_scan_directory(str(path))
    else:
        libs = [f.name for f in path.iterdir() if f.is_dir()]
    
    table = Table(title=f"Libraries in {folder}")
    table.add_column("Name", style="cyan")
    table.add_column("Status", style="green")
    
    for lib in sorted(libs):
        if lib.startswith("__"): continue
        status = "[yellow]Disabled[/yellow]" if lib.endswith(".disabled") else "[green]Active[/green]"
        table.add_row(lib, status)
    
    console.print(table)

@app.command()
def move(lib_name: str, src: str, dest: str):
    """Copy/Organize a library and its metadata from one folder to another."""
    src_path = Path(src)
    dest_path = Path(dest)
    dest_path.mkdir(parents=True, exist_ok=True)
    
    if smart.copy_library(src_path, dest_path, lib_name):
        console.print(f"[green]Successfully moved/copied {lib_name} from {src} to {dest}[/green]")
    else:
        console.print(f"[red]Library {lib_name} not found in {src}[/red]")

@app.command()
def disable(lib_name: str, folder: str = typer.Option(".", "--folder", "-f")):
    """Temporarily disable a library in the specified folder."""
    res = smart.toggle_library(Path(folder) / lib_name, True)
    console.print(f"[yellow]{res}: {lib_name}[/yellow]")

@app.command()
def enable(lib_name: str, folder: str = typer.Option(".", "--folder", "-f")):
    """Re-enable a disabled library in the specified folder."""
    res = smart.toggle_library(Path(folder) / lib_name, False)
    console.print(f"[green]{res}: {lib_name}[/green]")

@app.command()
def use(folder: str):
    """Enable a folder so your code only sees libraries within it."""
    path = Path(folder).absolute()
    if not path.exists():
        console.print(f"[red]Error: Folder {folder} not found.[/red]")
        return
    
    smart.inject_folder_to_sys_path(path)
    console.print(Panel(f"PyFuse Isolation Active\nTarget: [bold]{path}[/bold]\n\nYour session is now prioritized to this folder.", title="Success", border_style="green"))
    # Note: In a CLI, this only affects the current process. 
    # To use in a script, users should: import pyfuse; pyfuse.use('folder')

if __name__ == "__main__":
    app()
